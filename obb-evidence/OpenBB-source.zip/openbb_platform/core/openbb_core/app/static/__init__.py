"""OpenBB Core App Static."""
