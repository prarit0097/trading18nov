"""OpenBB Provider Abstract Class."""
