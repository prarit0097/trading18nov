"""Commercial Paper Standard Model."""

from datetime import (
    date as dateType,
)

from pydantic import Field

from openbb_core.provider.abstract.data import Data
from openbb_core.provider.abstract.query_params import QueryParams
from openbb_core.provider.utils.descriptions import (
    DATA_DESCRIPTIONS,
    QUERY_DESCRIPTIONS,
)


class CommercialPaperParams(QueryParams):
    """Commercial Paper Query."""

    start_date: dateType | None = Field(
        default=None,
        description=QUERY_DESCRIPTIONS.get("start_date", ""),
    )
    end_date: dateType | None = Field(
        default=None,
        description=QUERY_DESCRIPTIONS.get("end_date", ""),
    )


class CommercialPaperData(Data):
    """Commercial Paper Data.

    Attributes
    ----------
    date : dateType
        The observation date. Every maturity requested is carried as its own
        column, named for the maturity and category it reports.
    """

    date: dateType = Field(description=DATA_DESCRIPTIONS.get("date", ""))
