"""Argparse translator package."""
