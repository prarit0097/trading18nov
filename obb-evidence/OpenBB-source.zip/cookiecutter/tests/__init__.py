"""openbb-cookiecutter tests."""
